import sys
sys.real_prefix = sys.prefix
sys.prefix = sys.exec_prefix = '/home/szymo/Pulpit/workspace_ws/install/py_pubsub'
