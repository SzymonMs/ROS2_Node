import rclpy
import numpy as np
import cv2 as cv
from rclpy.node import Node

from geometry_msgs.msg import Twist

img = np.zeros((512, 512, 3), np.uint8)
cv.imshow("image", img)
msg = Twist()

class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('minimal_publisher')
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        timer_period = 1  # seconds
        self.timer = self.create_timer(timer_period, cv.setMouseCallback('image', self.mouse_click))
        self.i = 0

    def mouse_click(self, event, x, y,
                    flags, param):
        global direction
        global msg
        if event == cv.EVENT_LBUTTONDOWN:
            img = np.zeros((512, 512, 3), np.uint8)
            cv.imshow("image", img)
            cv.rectangle(img, (x, y), (x + 80, y + 80), (0, 255, 0), 2)
            cv.imshow("image", img)
            if (y < 256):
                print("UP")
                msg.linear.x = 0.0
                msg.linear.y = 1.0
                msg.linear.z = 0.0
                msg.angular.x = 0.0
                msg.angular.y = 0.0
                msg.angular.z = 0.0
                self.publisher_.publish(msg)
                self.get_logger().info('Publishing')
                self.i += 1
            if (y > 256):
                print("DOWN")
                msg.linear.x = 0.0
                msg.linear.y = -1.0
                msg.linear.z = 0.0
                msg.angular.x = 0.0
                msg.angular.y = 0.0
                msg.angular.z = 0.0
                self.publisher_.publish(msg)
                self.get_logger().info('Publishing')
                self.i += 1

def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = MinimalPublisher()
    cv.waitKey(0)
    cv.destroyAllWindows()
    rclpy.spin(minimal_publisher)
    minimal_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
